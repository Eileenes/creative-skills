# onetake-sandbox-setup

Created by: Tao Eileeness
Description: 在 Notion AI 的 Linux 沙盒里（没有 GPU、只有 2 核、没下载 playwright 浏览器）跑通 Onetake（http://github.com/feitangyuan/onetake）和 three.js 动效渲染：克隆仓库、改用系统 Chromium 加 SwiftShader、把 three.js 打包成 IIFE、图片内联成 base64、补装 scipy、估算渲染时间。适用于：任何用到 Onetake、http://render.py、http://stills.py、verify_http://promo.py，或在沙盒里逐帧渲染 WebGL/three.js 网页成视频的任务。
Files: onetake-sandbox-setup/mascot-ui-film-kit.zip

## 一键准备

解压 Files 里的 `mascot-ui-film-kit.zip`，执行 `bash mascot-ui-film-kit/setup.sh /data/film`（已经测试过能用）。它会：

1. 把 `onetake` 克隆到工作目录；
2. `pip3 install scipy`（沙盒里缺这个，sfx_palette 和 verify 要用）；
3. 把所有 `chromium.launch()` 改成用系统的 `chromium` 路径，加上 SwiftShader 参数；并把 [render.py](http://render.py) 里的 `GPU_ARGS` 换成 SwiftShader 参数，渲染时照常加 `--gpu`；
4. 用 esbuild 把 `three@0.180` 和 RoundedBoxGeometry 打包成 `three.bundle.js`，在页面里就是 `window.THREE` 和 `window.THREEX`；
5. 把 `motion.js` 复制到工作目录。

## 要点

- 页面是用 `file://` 打开的，ES 模块和 fetch 都用不了：three.js 必须用打包好的 IIFE，图片要转成 base64 写进 `.js`（`make_assets.py`）。
- WebGL 渲染器要设 `preserveDrawingBuffer: true`，截图才不会是黑的。
- 中文直接用系统字体 `"Noto Sans SC"`，等宽字体用 `"Liberation Mono"`。canvas 里的系统字体不需要等待加载。
- 斜着看的文字贴图要设 `anisotropy = renderer.capabilities.getMaxAnisotropy()`，否则看不清。
- **速度**：720p 每次截图约 0.65 秒。用 `--samples-max 10 --gap 12` 限制运动模糊的采样数，19 秒成片约 2,400 次截图、19 分钟（2 个 worker）。开始前要告诉用户。
- 长时间渲染放到后台：`(nohup python3 … > render.log 2>&1 &)`，再用 `while ! grep -qE "wrote|Traceback" render.log; do sleep 20; done` 配合 `wait` 轮询。
- Onetake 是 PolyForm Noncommercial 许可，只能非商业使用；它的源码要用的时候现场克隆，不要放进 skill 文件里分发。