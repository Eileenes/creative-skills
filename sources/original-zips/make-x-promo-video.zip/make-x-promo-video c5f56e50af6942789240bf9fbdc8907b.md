# make-x-promo-video

Created by: Tao Eileeness
Description: 套用「体素鲸鱼 × X 关注」19 秒宣传片模板，给任意 X 账号/产品出片。触发：给 @某账号 做宣传视频、套用鲸鱼宣传片、换账号/换吉祥物颜色/换终端命令重做一版、做个 follow me on X 的 3D 小片子。
Files: make-x-promo-video/x-promo-video-kit.zip

## 做什么

用附件 **x-promo-video-kit.zip**（Files 属性）给任意 X 账号生成 19 秒 1280×720 宣传片：终端输入一个词 → 体素鲸鱼孵化 → Dock → Safari → x.com → 搜索 @handle → 个人主页 → 鲸鱼踩下 Follow（粉丝数 N→N+1）→ 片尾卡。时间线固定，**每次只改 config.json，不改 comp.html**。

## 需要的输入（缺了就问，最多问一次）

| 输入 | 例子 | 默认 |
| --- | --- | --- |
| X 账号 handle | @Eileeness160708 | 必填 |
| 终端里敲的词（产品/品牌） | deepseek | 必填 |
| 吉祥物颜色 | #4D6BFE（DeepSeek 蓝） | #4D6BFE |
| 片尾标语 | 产品经理 · Vibe Coding · 测评 AI 新工具 | 简介前两行 |
| 右栏热搜 / 推荐关注（可选） | DeepSeek V4、@deepseek_ai | 通用值 |

## 步骤

1. **取套件**：把本页 Files 里的 zip 上传到电脑，`cd /data && unzip -o x-promo-video-kit.zip`。
2. **安装**：`bash /data/xpromo/setup.sh /data/film && cd /data/film`（克隆 Onetake、打包 three.js、改用系统 Chromium+SwiftShader，约 20 秒）。
3. **抓资料**：先运行 `agent-browser skills get core`，然后用 bash（browser:true）运行 `export AGENT_BROWSER_SESSION="$(agent-browser session id --scope worktree --prefix xpromo)"; bash fetch_x_profile.sh <handle> > profile.json`。未登录也能用；结束后执行 `agent-browser close`。抓不到时，让用户提供名字、简介、粉丝数和头像。
4. **生成配置**：`python3 init_config.py profile.json --typed <词> --color "<hex>" --tagline "<标语>"`，然后检查 config.json：bio 最多 4 行（长行会自动换行），按需补充 trends / whoToFollow / termFooter。
5. **构建**：`python3 build.py config.json`（会下载头像和横幅，并写入 config.js + assets.js；注意看 warn）。
6. **出片**：`bash render.sh promo.mp4` → 先看 stills.png（15 张关键帧），有问题就改 config 后重新 build；没问题就后台渲染，每隔几分钟看一次 `tail -1 render.log`（2 核约 19 分钟）。
7. **验收**：`python3 onetake/scripts/verify_promo.py promo.mp4`。除 rest（静止占比）外都应通过——参考片本身也只有约 9%，这项可以忽略。
8. **交付**：用 download_file_from_sandbox 下载 mp4（video/mp4），回复里附视频和一句话说明。

## config.json 字段

| 字段 | 说明 |
| --- | --- |
| handle / name / verified | 账号、显示名、蓝 V 开关 |
| bio[] / resultBio | 主页简介（≤4 行）/ 搜索结果里的一行简介 |
| link / joined | 主页链接和加入时间文字 |
| following / followers | 数字会从 N 滚到 N+1；字符串（如 "1.1M"、"1.2万"）不滚动 |
| avatar / banner | URL 或本地路径（pbs.twimg 400x400 / 1500x500） |
| typed / termTitle / termFooter | 终端里敲的词 / 窗口标题 / 结尾提示 |
| mascot.color / mascot.belly | 鲸鱼主色 / 肚皮色 |
| trends[[类目,话题]] / whoToFollow[[名,@,色]] | 右栏内容 |
| end.title / subtitle / tagline | 片尾大字（过长会自动缩小）/ Follow 行 / 标语 |
| addr | 地址栏起始文字，默认 x.com |

## 规则与坑

- 默认只出 720p；1080p/4K 要先问用户（渲染时间是 2.25 倍或 9 倍）。
- 不改 comp.html 的时间线；想加新镜头或新吉祥物造型，先用 **voxel-mascot**、**analyze-reference-video** skill。
- 换吉祥物颜色只改 mascot.color；配色太浅时，把 belly 设为更浅的同色系颜色。
- 终端字体没有 ❯，已用 >，不要改回来。
- 显示名超过 18 个字或 handle 很长时，必须看 stills 里搜索框、主页和片尾的效果。
- Onetake 采用 PolyForm Noncommercial 许可，仅限个人或非商业使用；如果用户要商用，需要提醒。
- 安装失败时参考 **onetake-sandbox-setup**。

## 输出

- 成片 mp4（720p30，含合成音效）+ 一句话说明（账号、颜色、时长）。
- 如有需要，附上 stills.png 预览和 config.json，方便下次微调。