# make-web-promo-video

Created by: Tao Eileeness
Description: 套用「体素鲸鱼」19 秒宣传片模板，给任意网页/产品官网/个人站出片（搜索 → 结果 → 网站首屏 → 鲸鱼踩下 CTA 按钮）。触发：给某个网站/网页/产品官网做宣传视频、网页版鲸鱼宣传片、换网址/颜色重做一版。
Files: make-web-promo-video/promo-video-kit.zip

## 做什么

用 Files 里的 [**promo-video-kit.zip**](http://promo-video-kit.zip)（platform = `web`）生成 19 秒、1280×720 的宣传片：终端敲一个词 → 体素鲸鱼孵化 → Dock（地球图标）→ Safari → 搜索站点名 → 搜索结果（图标、域名、简介）→ 网站页面（横幅是真实首屏截图）→ 鲸鱼踩下 CTA 按钮（如「立即体验」）→ 片尾「访问 域名」。**只改 config.json，不改 comp.html。**

## 需要的输入（缺了就问，只问一次）

| 输入 | 例子 | 默认 |
| --- | --- | --- |
| 网址 | [pm-terminal-8j0cbg6i15d.qoder.zone](http://pm-terminal-8j0cbg6i15d.qoder.zone) | 必填 |
| 终端里敲的词 | eileeness / 产品名 | 必填 |
| 显示名称 | 陶野 Eileeness | 网页的 og:site_name 或标题 |
| CTA 按钮文字 | 立即体验 / 进入终端 / Get started | 立即访问 |
| 鲸鱼颜色 | #4D6BFE 或品牌色 | #4D6BFE |
| 片尾标语 | 10 年产品经理的个人终端 | meta description |

## 步骤

1. 把本页 Files 里的 zip 上传到电脑：`cd /data && unzip -o promo-video-kit.zip && bash /data/xpromo/setup.sh /data/film && cd /data/film`
2. 抓页面：先运行 `agent-browser skills get core`，再用 bash（browser:true）运行 `export AGENT_BROWSER_SESSION="$(agent-browser session id --scope worktree --prefix xpromo)"; bash fetch_web_page.sh <网址> > profile.json`，最后执行 `agent-browser close`。脚本会拿到标题、描述和图标，并把首屏截图保存为 hero.png（作为横幅）。
    - **必须用 view_image 看一眼 hero.png**：如果是报错页、空白页或 Cookie 弹窗，就换个路径、关掉弹窗后重新截图，或者让用户提供截图。
    - 网站标题常常很怪（比如「user@host: ~」），用 `--name` 改成好看的名字。
3. `python3 init_config.py profile.json --typed <词> --name "<显示名>" --cta "<按钮文字>" --color "<hex>" --tagline "<标语>"`
4. 检查 config.json：bio 最多 4 行；trends（相关搜索）会根据名字自动生成，whoToFollow（相关网站）可以换掉；想显示数据，可以加 `"stats": [[1200, "用户"], ["4.9", "评分"]], "roll": 0`。
5. `python3 build.py config.json`（favicon 404 时会自动生成首字母头像；最好用 180px 以上的 png 图标）。
6. `bash render.sh promo.mp4` → 先看 stills.png，没问题就让它在后台渲染（约 19 分钟），每隔几分钟看一次 `tail -1 render.log`。
7. `python3 onetake/scripts/verify_promo.py promo.mp4`：除 rest 外都应通过，然后用 download_file_from_sandbox 交付 mp4。

## 网页专属字段

| 字段 | 说明 |
| --- | --- |
| url | 站点地址（会显示在主页和片尾，并决定地址栏内容） |
| name / bio | 显示名 / 描述 |
| banner | 首屏截图 hero.png（也可以换成任意 1500×500 图） |
| ui.follow | CTA 文字：`["立即体验", "✓ 立即体验"]`（`--cta` 会自动设置） |
| addr | 地址栏先输入的搜索站，默认 [bing.com](http://bing.com) |
| stats / roll | 可选的数据行；roll 是会 +1 滚动的那一项的序号，-1 表示都不滚动 |

## 坑

- 有些站点在无头浏览器里会报错或弹验证（比如 [deepseek.com](http://deepseek.com) 会出现 Application error），这时让用户提供截图和文字。
- 同一个工作目录里 hero.png 会被覆盖，一个目录只做一部片。
- 默认只出 720p，1080p/4K 要先问用户。Onetake 仅限个人或非商业使用。
- 想换新镜头或新形象，用 **analyze-reference-video** / **voxel-mascot**；安装失败时看 **onetake-sandbox-setup**。

## 输出

成片 mp4（720p30，含音效），加一句话说明（网站、颜色、时长）；需要的话附上 stills.png 和 config.json。