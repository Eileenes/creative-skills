# make-wechat-promo-video

Created by: Tao Eileeness
Description: 套用「体素鲸鱼」19 秒宣传片模板，给微信公众号出片（搜一搜 → 公众号主页 → 鲸鱼踩下绿色「关注公众号」）。触发：给公众号做宣传视频、公众号版鲸鱼宣传片、换公众号/颜色重做一版。
Files: make-wechat-promo-video/promo-video-kit.zip

## 做什么

用 Files 里的 [**promo-video-kit.zip**](http://promo-video-kit.zip)（platform = `wechat`）生成 19 秒、1280×720 的宣传片：终端敲一个词 → 体素鲸鱼孵化 → Dock（微信图标）→ Safari → 搜索公众号名 → 公众号结果 → 公众号主页（微信号、功能介绍、主体、原创数/朋友关注数）→ 鲸鱼踩下绿色「关注公众号」按钮，变成「已关注 ✓」→ 片尾「微信搜一搜「名字」」。**只改 config.json，不改 comp.html。**

## 需要的输入（缺了就问，只问一次）

| 输入 | 例子 | 默认 |
| --- | --- | --- |
| 该公众号任意一篇文章链接 | [https://mp.weixin.qq.com/s/…](https://mp.weixin.qq.com/s/…) | 必填；没有就手动提供资料 |
| 终端里敲的词 | wechat / 你的产品名 | 必填 |
| 鲸鱼颜色 | #07C160（微信绿），肚皮 #dcf7e8 | #07C160 |
| 片尾标语 | 每周一篇 AI 工具实测 | 功能介绍 |
| 原创文章数 / 关注人数（可选） | 268 / 37 | 不填就不显示统计行 |
| 是否认证（可选） | 是 | 否 |

## 步骤

1. 把本页 Files 里的 zip 上传到电脑：`cd /data && unzip -o promo-video-kit.zip && bash /data/xpromo/setup.sh /data/film && cd /data/film`
2. 抓资料（不需要浏览器）：`python3 fetch_wechat_profile.py "<文章链接>" > profile.json`，会从文章页拿到名称、微信号、功能介绍和头像。
    - 公众号没有公开的粉丝数。用户给了数字，就把 `articles`（篇原创内容）和 `followers`（位朋友关注，会 +1 滚动）写进 profile.json；认证号设置 `"verified": true`；可加 `"subject": "公司名"`。
    - 如果报「未解析到公众号信息」，就换一篇文章链接，或参照 `examples/wechat.json` 手写。
3. `python3 init_config.py profile.json --typed <词> --color "#07C160" --belly "#dcf7e8" --tagline "<标语>"`
4. 检查 config.json：bio 最多 4 行；trends（微信热搜）和 whoToFollow（相关公众号）可以换成相关内容。
5. `python3 build.py config.json`（没有横幅时会自动生成绿色渐变）。
6. `bash render.sh promo.mp4` → 先看 stills.png，没问题就让它在后台渲染（约 19 分钟），每隔几分钟看一次 `tail -1 render.log`。
7. `python3 onetake/scripts/verify_promo.py promo.mp4`：除 rest 外都应通过，然后用 download_file_from_sandbox 交付 mp4。

## 公众号专属字段

| 字段 | 说明 |
| --- | --- |
| name / id | 公众号名 / 微信号（没有 alias 时显示 gh_ 开头的原始 ID，可以手动改） |
| subject | 主体（显示为「主体：…」） |
| articles / followers | 篇原创内容 / 位朋友关注（数字会滚动）；都不填就不显示 |
| end.subtitle | 默认「微信搜一搜「名称」」 |
| ui | 可覆盖按钮文字等，例如 `{"follow": ["关注", "已关注"]}` |

## 坑

- 地址栏会显示 [weixin.sogou.com](http://weixin.sogou.com)，主页显示 [mp.weixin.qq.com/profile。这是示意画面，不是真实网页。](http://mp.weixin.qq.com/profile。这是示意画面，不是真实网页。)
- 功能介绍很长时会自动换行，最后几个字可能单独占一行，可以手动拆成两行。
- 默认只出 720p，1080p/4K 要先问用户。Onetake 仅限个人或非商业使用。
- 想换新镜头或新形象，用 **analyze-reference-video** / **voxel-mascot**；安装失败时看 **onetake-sandbox-setup**。

## 输出

成片 mp4（720p30，含音效），加一句话说明（公众号、颜色、时长）；需要的话附上 stills.png 和 config.json。