# make-popup-showcase-video

Created by: Tao Eileeness
Description: 套用「主页立体弹出」23.5 秒介绍片模板（参考 @ChrisHKAI 给 @isnail 做的介绍片）：3D 斜放的账号主页 → 头像飞起爆成体素吉祥物 → 吉祥物跳上 2 篇代表作封面，封面像立体书一样立起、分层弹出、数据滚动（如 304万阅读、46K粉）→ 甩镜到黑色舞台，平台 logo 砸下，名字/账号/标语贴纸逐个拍下。支持 X、小红书、公众号三种皮肤。触发：给某个账号/博主做介绍片、个人 IP 宣传片、作品集立体弹出视频、复刻蜗牛哥那条介绍片、换账号/封面/平台/吉祥物重做一版。
Files: make-popup-showcase-video/showcase-video-kit.zip

## 做什么

用本页 Files 里的 `showcase-video-kit.zip` 生成 23.5 秒、1280×720@30、带合成音效的介绍片。时间线固定，**每次只改 config.json，不改 comp.html**。

| 时间 | 画面 |
| --- | --- |
| 0–2.3 s | 账号主页（X 深色 / 小红书、公众号浅色）斜放在黑色空间里，镜头掠过；头像像硬币一样弹起翻转 |
| 2.3–5 s | 头像爆开，方块拼成体素吉祥物，挥手，跳上第 1 篇封面 |
| 5–9 s | 封面从信息流里立起来（把吉祥物弹飞、空翻落地），上下两条横带分层弹出，地面亮蓝框，数据 0→目标值，吉祥物走过、挥手 |
| 9–16.7 s | 第 2 篇同一套，最后吉祥物跳上卡片顶端挥手，再飞出画面 |
| 16.7–23.5 s | 甩镜切到黑色舞台：平台 logo 砸下，吉祥物落在 logo 上；名字 → 账号 → 两段标语（白底 + 红底）贴纸逐个拍下 |

## 需要的输入（缺了就问，只问一次）

| 输入 | 说明 |
| --- | --- |
| 平台 | x / xhs / wechat（决定主页皮肤、片尾 logo） |
| 账号资料 | 名字、handle 或小红书号/微信号、简介 ≤3 行、关注/粉丝等数字、头像（横幅可空）。可以用抓取脚本拿 |
| 2 篇代表作 | 每篇：封面图（任意比例，竖图会自动拉高版面）、标题、要滚动的数据（如 value 304 + unit 万 + label 阅读） |
| 片尾 | title（名字）、handle 行、slogan 两段，如 ["公众号变现", "找蜗牛"] |
| 吉祥物（可选） | 耳朵 rabbit/cat/bear/antenna/none + 头/衣服/裤子颜色 + 是否戴眼镜。尽量照用户头像的形象和配色来定；默认白兔 + 红衣 + 红蓝墨镜 |

## 步骤

1. 把本页 Files 里的 zip 上传到电脑：`cd /data && unzip -o showcase-video-kit.zip && bash showcase-video-kit/setup.sh /data/showcase-film && cd /data/showcase-film`（克隆 Onetake、打包 three.js，约 20 秒）。
2. 抓资料（可选）：
    - X：先运行 `agent-browser skills get core`，再用 bash（browser:true）跑 `bash fetch_x_profile.sh <handle> > profile.json`，结束后执行 `agent-browser close`。
    - 小红书：`bash fetch_xhs_profile.sh "<主页分享链接>"`（browser:true）；登录墙就直接向用户要资料。
    - 公众号：`python3 fetch_wechat_profile.py "<任一文章链接>"`；封面 + 标题：`python3 fetch_cover.py "<文章链接>" cover1.jpg`。
    - X 帖子 / 小红书笔记的封面一般抓不到，直接让用户发图。
3. 照着 `examples/x.json · xhs.json · wechat.json` 写 config.json（字段见 `README.md`）。
4. `python3 build.py config.json`，注意看 warn（标题过长、文字型数据不会滚动等）。
5. `bash render.sh showcase.mp4 --stills-only` → 用 view_image 看 stills.png（20 张关键帧）：吉祥物是否被遮挡、片尾贴纸是否压到 logo、封面文字是否清楚。有问题改 config 再 build。
6. `bash render.sh showcase.mp4` 后台渲染（2 核约 16 分钟），开始前告诉用户；用 `while ! grep -qE "wrote|Traceback" render.log; do sleep 25; done` 配合 wait 轮询。
7. `python3 onetake/scripts/verify_promo.py showcase.mp4`：除 rest 外都应通过（rest 这一项参考片本身也通不过，可以忽略）。
8. 用 download_file_from_sandbox 下载 mp4（video/mp4）交付，附一句话说明。

## 平台用法建议

- **小红书**：封面用笔记首图（3:4 竖图会自动变窄变高）；数据用「点赞」「收藏」「涨粉」；slogan 如 ["AI 工具测评", "关注我"]。发布时可以在剪映里加 9:16 上下黑边，或者直接发横版。
- **公众号**：封面用文章头图（2.35:1），数据用「阅读」「新增关注」；handle 写「微信搜一搜「名字」」。公众号没有公开粉丝数，没给就留空不显示。
- **X**：最接近参考片；article 封面或带图帖子都可以。

## 规则与坑

- 只改 config.json。镜头 CAM_A/CAM_B、吉祥物路线 ACTS 都已经按封面位置自动对齐，用户明确要求才改。
- 封面最好是**大字标题**的图：顶部 40% 和底部 24% 会作为弹出层，文字在这两条带里立体感最强。可以用 posts[].layers 调整，例如 `[[0.55,1,0.16],[0,0.3,0.32]]`。
- 只给 1 篇封面时会把它重复使用，效果会差一些，尽量要 2 篇。
- stat.value 用数字才会滚动；数字带小数时用 decimals 控制位数。
- 名字超过 10 个字或 slogan 很长时会自动缩小，一定要看 stills 的片尾。
- 默认只出 720p；1080p 要先问用户（渲染时间约 2.25 倍）。
- Onetake 是 PolyForm Noncommercial 许可，仅限个人或非商业使用；如果要拿去接单商用，必须提醒用户。
- 安装或渲染出错时参考 **onetake-sandbox-setup**；想换镜头或分析新的参考片，用 **analyze-reference-video**；想做新的体素形象，用 **voxel-mascot**。

## 输出

- 成片 mp4（23.5 秒，720p30，含音效），加一句话说明（账号、平台、两篇封面、时长）。
- 如有需要，附上 stills.png 和 config.json，方便下次微调。