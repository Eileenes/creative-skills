# make-xhs-promo-video

Created by: Tao Eileeness
Description: 套用「体素鲸鱼」19 秒宣传片模板，给小红书账号出片（搜索账号 → 主页 → 鲸鱼踩下红色「关注」→ 粉丝 +1）。触发：给小红书账号做宣传视频、小红书版鲸鱼宣传片、换小红书账号/颜色重做一版。
Files: make-xhs-promo-video/promo-video-kit.zip

## 做什么

用 Files 里的 [**promo-video-kit.zip**](http://promo-video-kit.zip)（platform = `xhs`）生成 19 秒、1280×720 的宣传片：终端敲一个词 → 体素鲸鱼孵化 → Dock（小红书图标）→ Safari → [xiaohongshu.com](http://xiaohongshu.com) → 搜索账号名 → 用户结果 → 个人主页（小红书号、IP 属地、关注/粉丝/获赞与收藏）→ 鲸鱼踩下红色「关注」按钮，变成「已关注」，粉丝数 N→N+1 → 片尾「小红书搜索「名字」」。**只改 config.json，不改 comp.html。**

## 需要的输入（缺了就问，只问一次）

| 输入 | 例子 | 默认 |
| --- | --- | --- |
| 小红书主页分享链接（App 里：我 → 分享 → 复制链接） | [https://www.xiaohongshu.com/user/profile/…](https://www.xiaohongshu.com/user/profile/…) | 必填；没有就手动提供资料 |
| 终端里敲的词 | xiaohongshu / 你的产品名 | 必填 |
| 鲸鱼颜色 | #FF2442（小红书红），肚皮 #ffe3e8 | #FF2442 |
| 片尾标语 | 产品经理 · 测评 AI 新工具 | 简介前两行 |
| 准确的粉丝数（可选） | 3580 | 未登录时只能抓到「10+」「1千+」这类粗略值 |

## 步骤

1. 把本页 Files 里的 zip 上传到电脑：`cd /data && unzip -o promo-video-kit.zip && bash /data/xpromo/setup.sh /data/film && cd /data/film`
2. 抓资料：先运行 `agent-browser skills get core`，再用 bash（browser:true）运行 `export AGENT_BROWSER_SESSION="$(agent-browser session id --scope worktree --prefix xpromo)"; bash fetch_xhs_profile.sh "<分享链接>" > profile.json`，最后执行 `agent-browser close`。
    - 如果 `loginWall: true` 或 name 为空：请用户提供昵称、小红书号、简介、关注/粉丝/获赞数和头像图片，然后参照 `examples/xhs.json` 手写 profile.json。
    - 粉丝数是数字时才会 +1 滚动；「1.2万」这类字符串不会滚动。用户给了准确数字就改成数字。
3. `python3 init_config.py profile.json --typed <词> --color "#FF2442" --belly "#ffe3e8" --tagline "<标语>"`
4. 检查 config.json：bio 最多 4 行（长行会自动换行）；trends（猜你想搜）和 whoToFollow（你可能感兴趣的人）可以换成和账号相关的内容。
5. `python3 build.py config.json`（头像是 webp 也没关系；没有横幅时会自动生成红色渐变）。
6. `bash render.sh promo.mp4` → 先看 stills.png，没问题就让它在后台渲染（约 19 分钟），每隔几分钟看一次 `tail -1 render.log`。
7. `python3 onetake/scripts/verify_promo.py promo.mp4`：除 rest 外都应通过，然后用 download_file_from_sandbox 交付 mp4。

## 小红书专属字段

| 字段 | 说明 |
| --- | --- |
| name / id | 昵称 / 小红书号（显示为「小红书号：…」） |
| ip | IP 属地 |
| following / followers / likes | 关注 / 粉丝（会滚动）/ 获赞与收藏 |
| end.subtitle | 默认「小红书搜索「昵称」」 |
| ui | 可覆盖 nav、tabs、follow 按钮文字等，例如 `{"follow": ["关注", "已关注"]}` |

## 坑

- 小红书网页版经常弹登录墙，抓不到时不要反复重试，直接向用户要资料。
- 搜索框里显示的是昵称（不是小红书号）；昵称超过 15 个汉字时要看 stills。
- 默认只出 720p，1080p/4K 要先问用户。Onetake 仅限个人或非商业使用。
- 想换新镜头或新形象，用 **analyze-reference-video** / **voxel-mascot**；安装失败时看 **onetake-sandbox-setup**。

## 输出

成片 mp4（720p30，含音效），加一句话说明（账号、颜色、时长）；需要的话附上 stills.png 和 config.json。